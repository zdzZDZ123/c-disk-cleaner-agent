#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
配置模块初始化文件
"""

from config.manager import ConfigManager

__all__ = ['ConfigManager']
